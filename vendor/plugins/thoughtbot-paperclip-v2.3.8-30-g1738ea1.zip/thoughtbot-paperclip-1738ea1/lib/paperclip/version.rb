module Paperclip
  VERSION = "2.3.8" unless defined? Paperclip::VERSION
end
