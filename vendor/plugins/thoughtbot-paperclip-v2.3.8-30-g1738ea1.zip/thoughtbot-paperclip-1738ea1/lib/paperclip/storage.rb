require "paperclip/storage/filesystem"
require "paperclip/storage/s3"
