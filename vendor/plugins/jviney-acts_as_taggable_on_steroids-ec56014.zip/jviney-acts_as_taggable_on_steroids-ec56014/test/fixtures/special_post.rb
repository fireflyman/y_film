class SpecialPost < Post
end
